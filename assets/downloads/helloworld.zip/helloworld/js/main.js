//On document ready
document.addEventListener("DOMContentLoaded", function(event) {
	// As there is no debug console in webportal 
	// this try-catch display errors in your HTML
	// during development process it has to be deleted 
	// for production application
	try {
		
		// Inform the parent window (applications portal) that the application is
		// loaded and ready
		window.parent.postMessage({
			'type' : 'WebPortal.onApplicationLoaded'
		}, '*');
		
		//Global messages listeners
		window.addEventListener("message", function(event){
		
			if (typeof event.data !== 'undefined' && typeof event.data.type !== 'undefined' ){
	
				var data = event.data;
				var type = event.data.type;
	
				switch(type){
	
				//When the application is killed or reloaded via an update
				case "WebPortal.onApplicationUnloaded":
					console.log("The application will be killed, it's time to save your application data");
				break;
	
				//When the application is put in background    
				case "WebPortal.onApplicationHide":  
					console.log("Application is hidden");
				break;
	
				//When the application is put in foreground
				case "WebPortal.onApplicationShow":
					console.log("Application is shown");
				break;
	
				//When a notification is pushed to the application
				case "WebPortal.onCurrentNotificationReceived":
					if (typeof data.value !== 'undefined'){
						console.log("Notification received" + data.value);
					if (typeof data.value === 'object'){
						console.log("Notification received : " + JSON.stringify(data.value));
					} else {
						console.log("Notification received : " + data.value);
					}
				}
				break;
				}
			}
		});
		
		try{
			// Connectivity
			if ((typeof Connectivity !== "undefined") && (typeof Connectivity.addEventListener !== "undefined")) {
				Connectivity.addEventListener("connectivityOn", function(){
					console.log("success, " + "Connectivity.connectivityOn()");
				});
				Connectivity.addEventListener("connectivityOff", function(){
					console.log("success, " + "Connectivity.connectivityOff()");
				});
			}
			
		} catch(e) {
			console.log('error, ' + 'CONNECTIVITY ' + e);
		}
		
		
		try {
			// Privacy
			if ((typeof Privacy !== "undefined") && (typeof Privacy.addEventListener !== "undefined")) {
				Privacy.addEventListener("ModePublic", function(){
					console.log("success, " + "Privacy.ModePublic()");
				});
				Privacy.addEventListener("ModeFull", function(){
					console.log("success, " + "Privacy.ModeFull()");
				});
				Privacy.addEventListener("ModeGeoloc", function(){
					console.log("success, " + "Privacy.ModeGeoloc()");
				});
			}
		} catch(e) {
			console.log('error, ' + 'Privacy ' + e);
		}
	} 
	// As there is no debug console in webportal 
	// this try-catch display errors in your HTML
	// during development process it has to be deleted 
	// for production application
	catch (error) {
	  var debugConsole = document.getElementById('debug-console'); 
	  debugConsole.innerHTML = error;
	}
});