var trads = {
    'en-GB': {
        notificationTitle: 'New notification',
        title:'Welcome in the demo App for ',
        subtitle:'Find car information bellow',
        VINLabel:'Vehicle Identification Number (VIN): ',
        UINLabel:'Unique Identification Number (UIN): ',
        kmTotalLabel:'Vehicle kms: ',
        sendkmTotalLabel: 'Send kms',
        drivingStateLabel:'Driving state: ',
        currentSpeedLabel:'Current speed: ',
    },
    'fr-FR': {
        notificationTitle: 'Nouvelle notification',
        title:'Bienvenue dans l\'application de démo pour ',
        subtitle:'Vous trouverez les informations de votre véhicule plus bas',
        VINLabel:'Numéro d\'Identification du Véhicule (VIN): ',
        UINLabel:'Numéro d\'Identification Unique (UIN): ',
        kmTotalLabel:'Kms du véhicule: ',
        sendkmTotalLabel: 'Envoyer kms',
        drivingStateLabel:'Conduite en cours: ',
        currentSpeedLabel:'Vitesse actuelle: ',
    }
};