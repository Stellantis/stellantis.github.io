/*---------------------
   NAC functions file
---------------------*/

initApp();

function displayApp() {
    console.log('Display App NAC');

    window.parent.postMessage({
        'type' : 'WebPortal.onApplicationLoaded'
    }, '*');
}

function initLanguage() {
    language = WebPortal.getLanguage();

    initTextContent(language);
}

function getCarData() {
    console.log('Init car data NAC');
    
    try {
        UIN = Device.GetUIN();
    } catch (e) { UIN = 'error';}

    kmTotal = Car.GetMileage(); 

    drivingState = Car.GetDrivingState();

    speedValue = Car.GetSpeed();

    initCarValues();
}

function subscribeToCarData() {
    
    Car.addEventListener('driverDistractionOn', function(){
        drivingState = true;
        $('#drivingStateValue').html('true');
    });

    Car.addEventListener('driverDistractionOff', function(){
        drivingState = false;
        $('#drivingStateValue').html('false');
    });

    setInterval(function() {  //EVENT DOESN'T EXIST IN NAC API
        speedValue = Car.GetSpeed();
        $('#speedValue').html(speedValue.toString());
    }, 200);

    window.addEventListener("message", function(event) {
        //MQTT MESSAGE
        if (event.data.type === 'WebPortal.onCurrentNotificationReceived') {
            console.log('MQTT Message: ', event.data.value.content);
            displayMQTTMessage(event.data.value.content);
        }
    });
}

function sendToMQTT(message) {
    //Message to OVIPNotification/from/{UIN}/exampleIVI
    console.log('MQTT message: ', message);
    window.parent.postMessage({
        'type': 'WebPortal.onSendNotificationRequest',
        'value': message},'*');
    }

