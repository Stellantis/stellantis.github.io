// Clone project: https://github.psa-cloud.com/opa00/demoApp.git


/*----------------------
    VAR DECLARATION
----------------------*/

var version = 'v0.0.1';
var defaultLanguage = 'en-GB';
var device;
var VIN;
var UIN;


var language;
var kmTotal;
var drivingState;
var speedValue;

/*----------------------
    DOM LOADED
----------------------*/

$(document).ready(function() {
    checkDevice(); //see NAC_functions and SDK to see init app call

    $('#version').html(version);
    $('#notification').hide();

    $('#sendkmTotal').on('click', function(){
        console.log('Click on send Maintenance btn');
        sendToMQTT(kmTotal);
    });

});

/*----------------------
    CHECK IF NAC OR IVI
----------------------*/

function checkDevice() {

    try {
        VIN = Car.GetVINCode(); //NAC API
        device = 'NAC';
        console.log('DEVICE: NAC');
        dynamicallyLoadScript('./NAC_functions.js', 'text/javascript');
    } catch(e) {
        console.log(e);
        console.log('DEVICE: IVI');
        device = 'IVI';
        dynamicallyLoadScript('./IVI_functions.js', 'text/javascript');
        dynamicallyLoadScript('./SDK.js', 'module');
    }
}

/*----------------------
    INIT FUNCTIONS
----------------------*/
function initApp() {
    try {
        initLanguage();
        getCarData();
        subscribeToCarData();
        displayApp();
    } catch(e){
        $('#debug').html('ERROR: ' + e);
    }
}

function initTextContent(language) {
    //Set default language if doesn't exist in trads file
    if (!trads[language]) {
        console.log('Set default language');
        language = defaultLanguage;
    }
    currentTrad = trads[language];

    //init values in front page
    $('#title').html(currentTrad.title+device);
    $('#subtitle').html(currentTrad.subtitle);
    $('#VIN .label').html(currentTrad.VINLabel);
    $('#UIN .label').html(currentTrad.UINLabel);
    $('#kmTotal .label').html(currentTrad.kmTotalLabel);
    $('#sendkmTotal').val(currentTrad.sendkmTotalLabel);
    $('#drivingState .label').html(currentTrad.drivingStateLabel);
    $('#currentSpeed .label').html(currentTrad.currentSpeedLabel); 
}

function initCarValues() {
    $('#VINValue').html(VIN);
    $('#UINValue').html(UIN);
    $('#kmTotalValue').html(kmTotal.toString());
    $('#drivingStateValue').html(drivingState.toString());
    $('#speedValue').html(speedValue.toString());
}

/*---------------------
    Notifications
---------------------*/

function displayMQTTMessage(message) {
    //Title could come from a field in the MQTT msg
    $('#notificationTitle').html(trads[language].notificationTitle);
    $('#notificationContent span').html(message);
    $('#notification').show();

    //Close notification
    setTimeout(function(){
        $('#notification').hide();
    }, 7000);
}

/*---------------------
        Utils
---------------------*/

function dynamicallyLoadScript(url, type) {
    //We need to dynamically load the SDK module because NAC (ES5) doesn't support it

    var script = document.createElement("script");  // create a script DOM node
    script.src = url;  // set its src to the provided URL
    script.type = type;
    document.body.appendChild(script);  // add it to the end of the head section of the page (could change 'head' to 'body' to add it to the end of the body section instead)
}