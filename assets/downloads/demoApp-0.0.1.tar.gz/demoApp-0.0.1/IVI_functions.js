/*---------------------
   IVI functions file
---------------------*/

function displayApp() {
    console.log('Display App IVI');

    myIDP.set('app.loadingStatus', {status: 'running'});
}

async function initLanguage() {
    console.log('Init trads IVI');

    languageResponse = await myIDP.get('settings.language');
    language = languageResponse.data ? languageResponse.data : 'default';
    initTextContent(language);
}

async function getCarData() {
    console.log('Init car data IVI');

    let VINResponse = await myIDP.get('configuration.VIN');
    VIN = VINResponse.data;

    let UINResponse = await myIDP.get('system.uin');
    UIN = UINResponse.data.CarData.uin;

    let kmTotalResponse = await myIDP.get('engine.totalMileage');
    kmTotal = kmTotalResponse.data;

    let drivingStateResponse = await myIDP.get('driving.drivingState');
    drivingState = drivingStateResponse.data;

    let speedValueResponse = await myIDP.get('driving.speedValue');
    speedValue = speedValueResponse.data;

    initCarValues();
}

function subscribeToCarData() {
    
    myIDP.subscribe('driving.drivingState', '', function(event){
        drivingState = event.data;
        $('#drivingStateValue').html(drivingState);
    });

    myIDP.subscribe('driving.speedValue', '', function(event){
        speedValue = event.data;
        $('#speedValue').html(speedValue);
    });

    myIDP.subscribe('MQTT.messageReceived', '', function(event){
        //Message from OVIPNotification/to/{UIN}/exampleIVI
        console.log('Message from MQTT received: ', event);

        if (event.data.event === 'published') {
            console.log('Message published');
            return;
        }
        let message = JSON.parse(event.data.message);
        console.log('Message received: ', message);

        //You can do anything with the content
        displayMQTTMessage(message.content);
    });
}


/*------------------
    MQTT functions
------------------*/

function sendToMQTT(MQTTMessage) {
    //Message to OVIPNotification/from/{UIN}/exampleIVI
    console.log('Send Message to MQTT: ', MQTTMessage);
    myIDP.set('MQTT.publish', {payload: JSON.stringify({content:message})});
}

function displayMQTTMessage(message) {
    //Title could come from a field in the MQTT msg
    $('#notificationTitle').html(trads[language].notificationTitle);
    $('#notificationContent span').html(message);
    $('#notification').show();

    //Close notification
    setTimeout(function(){
        $('#notification').hide();
    }, 7000);
}