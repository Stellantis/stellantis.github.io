/*---------------------
    Import SDK
---------------------*/

(async () => {
    const {default : IDPClient} = await import('/front-ivi/online/sdk/WebPortal_IDP_Client.js');
    window.myIDP = new IDPClient();
    console.log('SDK loaded');

    initApp();
})()